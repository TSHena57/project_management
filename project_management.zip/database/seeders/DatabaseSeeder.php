<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\ProjectPhase;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::create([
            'name' => 'Tahsin Sorwar',
            'email' => 'tahsin@example.com',
            'password' => Hash::make("tahsin@example.com"),
        ]);
        ProjectPhase::create([
            'name' => 'No Phase',
            'is_active' => 1,
        ]);
    }
}
